(() => {
  'use strict';
  const KEY = 'girlsLifeMvpV1';
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const defaultState = () => ({
    name:'Санду', language:'kk', theme:'light', tasks:[], water:0, mood:'',
    morning:[false,false,false,false], evening:[false,false,false,false],
    journals:[], dreams:[], transactions:[], studyNote:''
  });
  let state;
  try { state = {...defaultState(), ...JSON.parse(localStorage.getItem(KEY) || '{}')}; }
  catch { state = defaultState(); }
  let toastTimer, timerInterval=null, timerSeconds=25*60, timerRunning=false, timerBreak=false;
  const translations = {
    kk:{
      workspace:'ЖЕКЕ КЕҢІСТІК',home:'Басты бет',planner:'Жоспар',journal:'Күнделік',dreams:'Армандар картасы',finance:'Қаржы',study:'Оқу және даму',settings:'Баптаулар',sideQuote:'Өзіңе жасаған кішкентай қамқорлық та маңызды.',
      hello:'Сәлем, сұлу жан!',todayQuestion:'Бүгін өзің үшін не істейсің?',heroText:'Үлкен өзгерістер кішкентай қадамдардан басталады. Бүгін өзіңе уақыт бөл.',planDay:'Күнімді жоспарлау',dailyRitual:'КҮНДЕЛІКТІ ӘДЕТТЕР',yourDay:'Сенің күнің',seeAll:'Барлығын көру ↗',water:'Су ішу',glasses:'стақан',checkIn:'КҮНДЕЛІК БЕЛГІ',mood:'Көңіл күй',howFeel:'Қазір өзіңді қалай сезінесің?',focus:'НАЗАР',tasksToday:'Бүгінгі тапсырмалар',keepGoing:'Кішкентай қадам — үлкен нәтиже',yourPriorities:'БАСЫМДЫҚТАР',todayPlan:'Бүгінгі жоспар',addTaskPlaceholder:'Бүгін не істегің келеді?',openPlanner:'Жоспарды ашу →',thoughtOfDay:'КҮН ОЙЫ',littleThings:'ӨЗІҢ ҮШІН',exploreSpace:'Кеңістігіңді зертте',selfCareSub:'Өзіңе қамқорлық жасау',journalSub:'Ойларың мен сезімдерің',dreamSub:'Армандарыңа бір қадам',financeSub:'Қаржыңды ретте',plannerTitle:'Жоспар — өз уақытыңның иесі бол',plannerDesc:'Міндеттеріңді жаз, басымдық бер және әр қадамыңды бағала.',taskList:'Тапсырмалар тізімі',normal:'Қалыпты',high:'Маңызды',add:'Қосу +',pomodoroDesc:'25 минут зейін қойып оқы, кейін қысқа үзіліс жаса.',start:'Бастау',pause:'Үзіліс',reset:'Қайта бастау',selfCareTitle:'өзіңе қамқорлық',selfCareDesc:'Мінсіз болуға емес, өзіңді жақсы сезінуге көңіл бөл.',morningRoutine:'Таңғы рутина',eveningRoutine:'Кешкі рутина',gentleReminder:'Өзіңе жұмсақ бол',gentleReminderText:'Демалу да — өнімділіктің бір бөлігі. Бүгін қолыңнан келгені жеткілікті.',journalTitle:'Жүрегіңе жақын жазбалар',journalDesc:'Мұнда ойыңды реттеп, күніңдегі кішкентай қуаныштарды сақтай аласың.',journalPrompt:'Бүгін ойыңда не бар?',journalPlaceholder:'Өзіңе хат жазғандай еркін жаз...',privateNote:'♡ Жеке жазба',saveNote:'Жазбаны сақтау',localPrivacy:'Бұл демо-нұсқада жазбалар осы браузерде ғана сақталады.',savedNotes:'Сақталған жазбалар',dreamTitle:'Армандарыңа орын бер',dreamDesc:'Әр арман — өзіңе берген уәдең. Оны кішкентай қадамдармен жақындат.',yourDreams:'Менің армандарым',dreamPlaceholder:'Мақсатыңды жаз...',addDream:'Арман қосу +',financeTitle:'Қаржыңа саналы көзқарас',financeDesc:'Кіріс пен шығысты тіркеп, мақсатыңа сай жоспар құр.',balance:'Жалпы баланс',balanceSub:'Тіркелген барлық операция',income:'Кіріс',moneyIn:'+ Ақша түсті',expense:'Шығыс',moneyOut:'− Ақша жұмсалды',addTransaction:'Операция қосу',expensePlaceholder:'Мысалы, кітап немесе шәкіртақы',financePrivacy:'Қаржы деректері тек осы браузерде сақталады. Банкпен байланыс жоқ.',studyTitle:'Оқу — өзіңе салған инвестиция',studyDesc:'Бүгін үйренген бір нәрсең ертеңгі мүмкіндігіңе айналады.',studyNotes:'Оқу жазбалары',studyNotesSub:'Маңызды ойларды күнделікке сақта',studyTimerSub:'Зейінді оқу таймері',studyGoal:'Оқу мақсаты',studyGoalSub:'Күн сайын аз да болса алға жылжу',quickStudyNote:'Жылдам оқу жазбасы',studyPlaceholder:'Бүгін нені үйрендің?',savedLocally:'Автоматты түрде осы браузерде сақталады',settingsTitle:'Баптаулар',settingsDesc:'Өзіңе ыңғайлы кеңістік қалыптастыр.',yourName:'Есімің',yourNameSub:'Қосымшада қалай атағанымды қалайсың?',save:'Сақтау',language:'Тіл',languageSub:'Өзіңе ыңғайлы тілді таңда.',appearance:'Көрініс',appearanceSub:'Жарық немесе қараңғы режим.',toggleTheme:'Режимді ауыстыру',exportData:'Деректерді экспорттау',exportSub:'Жергілікті деректеріңнің JSON көшірмесін жүктеп ал.',downloadCopy:'Көшірмені жүктеу ↓',clearData:'Барлық деректі тазалау',clearSub:'Бұл әрекет осы браузердегі GIRLS LIFE деректерін өшіреді.',clear:'Тазалау',aboutText:'Бұл — жеке құрылғыда жұмыс істейтін бастапқы нұсқа.',footerTag:'Өзіңе уақыт бөл. Өз жолыңмен жүр.',discover:'Зерттеу',profile:'Профиль'
    },
    ru:{
      workspace:'ЛИЧНОЕ ПРОСТРАНСТВО',home:'Главная',planner:'Планер',journal:'Дневник',dreams:'Карта желаний',finance:'Финансы',study:'Учёба и развитие',settings:'Настройки',sideQuote:'Даже маленькая забота о себе имеет значение.',
      hello:'Привет, прекрасная!',todayQuestion:'Что ты сделаешь сегодня для себя?',heroText:'Большие перемены начинаются с маленьких шагов. Найди сегодня время для себя.',planDay:'Планировать день',dailyRitual:'ЕЖЕДНЕВНЫЕ ПРИВЫЧКИ',yourDay:'Твой день',seeAll:'Посмотреть всё ↗',water:'Вода',glasses:'стаканов',checkIn:'ОТМЕТКА',mood:'Настроение',howFeel:'Как ты себя чувствуешь?',focus:'ФОКУС',tasksToday:'Задачи на сегодня',keepGoing:'Маленький шаг — большой результат',yourPriorities:'ПРИОРИТЕТЫ',todayPlan:'План на сегодня',addTaskPlaceholder:'Что хочешь сделать сегодня?',openPlanner:'Открыть планер →',thoughtOfDay:'МЫСЛЬ ДНЯ',littleThings:'ДЛЯ СЕБЯ',exploreSpace:'Исследуй своё пространство',selfCareSub:'Забота о себе',journalSub:'Мысли и чувства',dreamSub:'Шаг к мечтам',financeSub:'Управляй финансами',plannerTitle:'Планер — управляй своим временем',plannerDesc:'Записывай задачи, расставляй приоритеты и цени каждый шаг.',taskList:'Список задач',normal:'Обычный',high:'Важный',add:'Добавить +',pomodoroDesc:'Сосредоточься на 25 минут, затем сделай небольшой перерыв.',start:'Старт',pause:'Пауза',reset:'Сбросить',selfCareTitle:'забота о себе',selfCareDesc:'Сосредоточься не на идеале, а на своём самочувствии.',morningRoutine:'Утренний ритуал',eveningRoutine:'Вечерний ритуал',gentleReminder:'Будь к себе бережна',gentleReminderText:'Отдых — тоже часть продуктивности. Сегодня достаточно того, что ты смогла.',journalTitle:'Записи от сердца',journalDesc:'Упорядочивай мысли и сохраняй маленькие радости дня.',journalPrompt:'О чём ты думаешь сегодня?',journalPlaceholder:'Пиши свободно, будто пишешь письмо себе...',privateNote:'♡ Личная запись',saveNote:'Сохранить запись',localPrivacy:'В демо-версии записи хранятся только в этом браузере.',savedNotes:'Сохранённые записи',dreamTitle:'Дай мечтам место',dreamDesc:'Каждая мечта — обещание себе. Приближай её маленькими шагами.',yourDreams:'Мои мечты',dreamPlaceholder:'Запиши свою цель...',addDream:'Добавить мечту +',financeTitle:'Осознанный подход к финансам',financeDesc:'Записывай доходы и расходы, планируй в соответствии с целями.',balance:'Общий баланс',balanceSub:'Все добавленные операции',income:'Доход',moneyIn:'+ Деньги поступили',expense:'Расход',moneyOut:'− Деньги потрачены',addTransaction:'Добавить операцию',expensePlaceholder:'Например, книга или стипендия',financePrivacy:'Финансовые данные хранятся только в этом браузере. Банковского подключения нет.',studyTitle:'Учёба — инвестиция в себя',studyDesc:'То, что ты узнаешь сегодня, может стать возможностью завтра.',studyNotes:'Учебные заметки',studyNotesSub:'Сохраняй важные мысли в дневнике',studyTimerSub:'Таймер для учёбы',studyGoal:'Учебная цель',studyGoalSub:'Каждый день двигайся хоть немного вперёд',quickStudyNote:'Быстрая учебная заметка',studyPlaceholder:'Что ты сегодня узнала?',savedLocally:'Автоматически сохраняется в этом браузере',settingsTitle:'Настройки',settingsDesc:'Создай удобное для себя пространство.',yourName:'Твоё имя',yourNameSub:'Как к тебе обращаться в приложении?',save:'Сохранить',language:'Язык',languageSub:'Выбери удобный язык.',appearance:'Внешний вид',appearanceSub:'Светлая или тёмная тема.',toggleTheme:'Сменить тему',exportData:'Экспорт данных',exportSub:'Скачай JSON-копию локальных данных.',downloadCopy:'Скачать копию ↓',clearData:'Очистить все данные',clearSub:'Это удалит данные GIRLS LIFE из этого браузера.',clear:'Очистить',aboutText:'Это начальная версия для личного устройства.',footerTag:'Найди время для себя. Иди своим путём.',discover:'Обзор',profile:'Профиль'
    },
    en:{
      workspace:'PERSONAL SPACE',home:'Home',planner:'Planner',journal:'Journal',dreams:'Dream board',finance:'Finance',study:'Study & growth',settings:'Settings',sideQuote:'Even a little act of self-care matters.',
      hello:'Hello, lovely!',todayQuestion:'What will you do for yourself today?',heroText:'Big changes begin with small steps. Make a little time for yourself today.',planDay:'Plan my day',dailyRitual:'DAILY RITUALS',yourDay:'Your day',seeAll:'See all ↗',water:'Water intake',glasses:'glasses',checkIn:'CHECK-IN',mood:'Mood',howFeel:'How are you feeling right now?',focus:'FOCUS',tasksToday:'Today’s tasks',keepGoing:'Small steps lead to big things',yourPriorities:'YOUR PRIORITIES',todayPlan:'Today’s plan',addTaskPlaceholder:'What would you like to do today?',openPlanner:'Open planner →',thoughtOfDay:'THOUGHT OF THE DAY',littleThings:'JUST FOR YOU',exploreSpace:'Explore your space',selfCareSub:'Take care of yourself',journalSub:'Your thoughts and feelings',dreamSub:'One step toward your dreams',financeSub:'Manage your money',plannerTitle:'Planner — own your time',plannerDesc:'Write down tasks, set priorities and celebrate each step.',taskList:'Task list',normal:'Normal',high:'Important',add:'Add +',pomodoroDesc:'Focus for 25 minutes, then take a short break.',start:'Start',pause:'Pause',reset:'Reset',selfCareTitle:'self-care',selfCareDesc:'Focus on feeling well, not on being perfect.',morningRoutine:'Morning routine',eveningRoutine:'Evening routine',gentleReminder:'Be gentle with yourself',gentleReminderText:'Rest is part of productivity too. What you could do today is enough.',journalTitle:'Notes close to your heart',journalDesc:'Clear your mind and save the little joys of your day.',journalPrompt:'What’s on your mind today?',journalPlaceholder:'Write freely, as if writing a letter to yourself...',privateNote:'♡ Private note',saveNote:'Save note',localPrivacy:'In this demo, notes are saved only in this browser.',savedNotes:'Saved notes',dreamTitle:'Make room for your dreams',dreamDesc:'Every dream is a promise to yourself. Get closer one small step at a time.',yourDreams:'My dreams',dreamPlaceholder:'Write down your goal...',addDream:'Add dream +',financeTitle:'Be intentional with money',financeDesc:'Track income and expenses, and plan around your goals.',balance:'Total balance',balanceSub:'All recorded transactions',income:'Income',moneyIn:'+ Money received',expense:'Expense',moneyOut:'− Money spent',addTransaction:'Add transaction',expensePlaceholder:'For example, a book or scholarship',financePrivacy:'Financial data stays in this browser. No bank connection.',studyTitle:'Learning is an investment in yourself',studyDesc:'Something you learn today may become an opportunity tomorrow.',studyNotes:'Study notes',studyNotesSub:'Save important thoughts in your journal',studyTimerSub:'Focused study timer',studyGoal:'Study goal',studyGoalSub:'Make a little progress every day',quickStudyNote:'Quick study note',studyPlaceholder:'What did you learn today?',savedLocally:'Saved automatically in this browser',settingsTitle:'Settings',settingsDesc:'Make this space work for you.',yourName:'Your name',yourNameSub:'How would you like to be addressed?',save:'Save',language:'Language',languageSub:'Choose your preferred language.',appearance:'Appearance',appearanceSub:'Light or dark mode.',toggleTheme:'Toggle theme',exportData:'Export data',exportSub:'Download a JSON copy of your local data.',downloadCopy:'Download copy ↓',clearData:'Clear all data',clearSub:'This will erase GIRLS LIFE data from this browser.',clear:'Clear',aboutText:'This is an initial version for a personal device.',footerTag:'Make time for yourself. Walk your own path.',discover:'Discover',profile:'Profile'
    }
  };
  const routineDefaults = {
    morning:['Бір стақан су ішу','Бет күтімі','SPF қолдану','Күнге ниет қою'],
    evening:['Бет күтімі','Тіс тазалау','Ертеңгі күнді жоспарлау','Телефоннан үзіліс жасау']
  };
  const routineTranslations = {
    kk:{morning:['Бір стақан су ішу','Бет күтімі','SPF қолдану','Күнге ниет қою'],evening:['Бет күтімі','Тіс тазалау','Ертеңгі күнді жоспарлау','Телефоннан үзіліс жасау']},
    ru:{morning:['Выпить стакан воды','Уход за лицом','Нанести SPF','Настроиться на день'],evening:['Уход за лицом','Почистить зубы','Спланировать завтра','Сделать паузу от телефона']},
    en:{morning:['Drink a glass of water','Skincare','Apply SPF','Set an intention'],evening:['Skincare','Brush your teeth','Plan tomorrow','Take a break from your phone']}
  };
  const quotes = {
    kk:['Өзіңнің қарқыныңмен жүр. Гүл де өз уақытында ашылады.','Бүгінгі кішкентай қадамың — ертеңгі үлкен жетістігің.','Өзіңе сену — жолдың жартысы.','Өзіңе уақыт бөлу — өзіңді бағалаудың бір жолы.'],
    ru:['Иди в своём темпе. Цветы тоже распускаются в своё время.','Маленький шаг сегодня — большая возможность завтра.','Вера в себя — уже половина пути.','Время для себя — это тоже забота.'],
    en:['Grow at your own pace. Flowers bloom in their own time.','A small step today can open a door tomorrow.','Believing in yourself is half the journey.','Making time for yourself is an act of care.']
  };
  const t = key => (translations[state.language] && translations[state.language][key]) || translations.kk[key] || key;
  function save(){ try{localStorage.setItem(KEY,JSON.stringify(state));}catch(e){showToast('Сақтау мүмкін болмады. Браузер жадын тексеріңіз.');} renderStats(); }
  function showToast(message){const el=$('#toast');el.textContent=message;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2600);}
  function escapeHTML(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function dateKey(){const d=new Date();return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`;}
  function updateDate(){const d=new Date();$('#todayLabel').textContent=d.toLocaleDateString(state.language==='kk'?'kk-KZ':state.language==='ru'?'ru-RU':'en-US',{weekday:'long',day:'numeric',month:'long',year:'numeric'});}
  function applyTranslations(){
    $$('[data-i18n]').forEach(el=>{const key=el.dataset.i18n;if(t(key))el.textContent=t(key);});
    $$('[data-i18n-placeholder]').forEach(el=>{el.placeholder=t(el.dataset.i18nPlaceholder);});
    $('#profileName').textContent=state.name||'S';$('#avatarInitial').textContent=(state.name||'S').trim().charAt(0).toUpperCase();
    $('#nameInput').value=state.name||'';$('#languageSelect').value=state.language;$('#studyNote').value=state.studyNote||'';
    $('#themeToggle').textContent=state.theme==='dark'?'☀':'☾';
    $('#timerStart').textContent=timerRunning?t('pause'):t('start');
    updateDate();renderRoutines();renderTasks();renderJournals();renderDreams();renderFinance();renderStats();
    $('#dailyQuote').textContent=(quotes[state.language]||quotes.kk)[(new Date().getDate())%(quotes[state.language]||quotes.kk).length];
    const taskOptions=$$('#taskPriority option');taskOptions.forEach(o=>o.textContent=t(o.value==='high'?'high':'normal'));
    $$('#financeType option').forEach(o=>o.textContent=t(o.value));
  }
  function showPage(page){
    if(page==='discover'){page='home';document.querySelector('.discover-heading')?.scrollIntoView({behavior:'smooth',block:'start'});}
    $$('.page').forEach(el=>el.classList.toggle('active',el.id===`page-${page}`));
    $$('.nav-item[data-page],.mobile-nav button[data-page]').forEach(el=>el.classList.toggle('active',el.dataset.page===page));
    if(page==='home')window.scrollTo({top:0,behavior:'smooth'});
    else window.scrollTo({top:0,behavior:'smooth'});
  }
  function renderStats(){
    $('#waterCount').textContent=state.water||0;$('#waterProgress').style.width=`${Math.min(100,(state.water||0)/8*100)}%`;
    const tasks=state.tasks||[],done=tasks.filter(x=>x.done).length;
    $('#taskDone').textContent=done;$('#taskTotal').textContent=`/ ${tasks.length}`;$('#taskProgress').style.width=tasks.length?`${done/tasks.length*100}%`:'0%';
    $('#plannerCount').textContent=`${tasks.length} TASKS`;
    $('#moodLabel').textContent=state.mood?({ '😊':'Көңіл күйің керемет!', '🙂':'Жақсы екен!', '😐':'Қалыпты күн де болады.', '😔':'Өзіңе жұмсақ бол.', '🥰':'Осы сезім ұзаққа жалғассын!' }[state.mood]||state.mood):t('howFeel');
    $$('.mood-options button').forEach(b=>b.classList.toggle('selected',b.dataset.mood===state.mood));
  }
  function renderTasks(){
    const render=(container,limit=null)=>{
      const el=$(container);if(!el)return;const tasks=state.tasks||[],visible=limit?tasks.slice(0,limit):tasks;
      if(!visible.length){el.innerHTML=`<div class="empty-state">${state.language==='ru'?'Пока нет задач — добавь первую.':state.language==='en'?'No tasks yet — add your first one.':'Әзірге тапсырма жоқ — біріншісін қос.'}</div>`;return;}
      el.innerHTML=visible.map(task=>`<div class="task-row ${task.done?'done':''}" data-id="${task.id}"><input class="task-check" type="checkbox" aria-label="Complete task" ${task.done?'checked':''}><span class="task-text">${escapeHTML(task.text)}</span>${task.priority==='high'?`<span class="task-priority">${escapeHTML(t('high'))}</span>`:''}<button class="delete-btn" data-delete-task="${task.id}" aria-label="Delete task">×</button></div>`).join('');
    };
    render('#homeTaskList',4);render('#plannerTaskList');
  }
  function addTask(text,priority='normal'){
    if(!text.trim())return;
    state.tasks.unshift({id:Date.now()+Math.random(),text:text.trim(),priority,done:false,created:dateKey()});save();renderTasks();
  }
  function renderRoutines(){
    ['morning','evening'].forEach(kind=>{
      const container=$(`#${kind}List`);if(!container)return;
      const items=(routineTranslations[state.language]||routineTranslations.kk)[kind];
      container.innerHTML=items.map((label,i)=>`<label class="check-row"><input type="checkbox" data-routine="${kind}" data-index="${i}" ${(state[kind]||[])[i]?'checked':''}><span>${escapeHTML(label)}</span></label>`).join('');
    });
  }
  function renderJournals(){
    const el=$('#journalEntries');if(!el)return;const entries=state.journals||[];
    if(!entries.length){el.innerHTML=`<div class="empty-state">${state.language==='ru'?'Здесь появятся твои записи.':state.language==='en'?'Your saved notes will appear here.':'Сақталған жазбаларың осында көрінеді.'}</div>`;return;}
    el.innerHTML=entries.map(e=>`<article class="journal-entry"><time>${escapeHTML(e.date)}</time><p>${escapeHTML(e.text)}</p><button class="delete-btn" data-delete-journal="${e.id}" aria-label="Delete note">× ${state.language==='en'?'Delete':state.language==='ru'?'Удалить':'Өшіру'}</button></article>`).join('');
  }
  function renderDreams(){
    const el=$('#dreamGrid');if(!el)return;const dreams=state.dreams||[];
    if(!dreams.length){el.innerHTML=`<div class="empty-state" style="grid-column:1/-1">${state.language==='ru'?'Добавь мечту, с которой хочешь начать.':state.language==='en'?'Add a dream you want to start working toward.':'Алғашқы арманыңды қосып көр.'}</div>`;return;}
    el.innerHTML=dreams.map(d=>`<article class="dream-card"><button class="delete-btn" data-delete-dream="${d.id}" aria-label="Delete dream">×</button><span class="dream-star">✧</span><div><h4>${escapeHTML(d.text)}</h4><small>${escapeHTML(d.category||'')}</small></div></article>`).join('');
  }
  function formatMoney(n){return new Intl.NumberFormat(state.language==='kk'?'kk-KZ':state.language==='ru'?'ru-RU':'en-US',{maximumFractionDigits:0}).format(n)+' ₸';}
  function renderFinance(){
    const tx=state.transactions||[],income=tx.filter(x=>x.type==='income').reduce((s,x)=>s+x.amount,0),expense=tx.filter(x=>x.type==='expense').reduce((s,x)=>s+x.amount,0);
    $('#balanceValue').textContent=formatMoney(income-expense);$('#incomeValue').textContent=formatMoney(income);$('#expenseValue').textContent=formatMoney(expense);
    const el=$('#financeList');if(!el)return;
    if(!tx.length){el.innerHTML=`<div class="empty-state">${state.language==='ru'?'Пока нет операций.':state.language==='en'?'No transactions yet.':'Әзірге операция жоқ.'}</div>`;return;}
    el.innerHTML=tx.map(x=>`<div class="finance-row"><span class="finance-symbol">${x.type==='income'?'↙':'↗'}</span><div><b>${escapeHTML(x.title)}</b><small>${escapeHTML(x.date)}</small></div><span class="finance-amount ${x.type==='income'?'positive':'negative'}">${x.type==='income'?'+':'−'} ${formatMoney(x.amount)}</span><button class="delete-btn" data-delete-tx="${x.id}" aria-label="Delete transaction">×</button></div>`).join('');
  }
  function toggleTheme(){state.theme=state.theme==='dark'?'light':'dark';document.body.classList.toggle('dark',state.theme==='dark');save();$('#themeToggle').textContent=state.theme==='dark'?'☀':'☾';}
  function timerRender(){const m=Math.floor(timerSeconds/60),s=timerSeconds%60;$('#timerDisplay').textContent=`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;$('#timerMode').textContent=timerBreak?'BREAK':'FOCUS';$('#timerStart').textContent=timerRunning?t('pause'):t('start');}
  function stopTimer(){if(timerInterval){clearInterval(timerInterval);timerInterval=null;}timerRunning=false;timerRender();}
  function startTimer(){
    if(timerRunning){stopTimer();return;}
    timerRunning=true;timerRender();
    timerInterval=setInterval(()=>{timerSeconds--;if(timerSeconds<=0){stopTimer();timerBreak=!timerBreak;timerSeconds=timerBreak?5*60:25*60;timerRender();showToast(timerBreak?'Фокус уақыты аяқталды. Үзіліс жаса!':'Үзіліс аяқталды. Жалғастыруға болады!');}else timerRender();},1000);
  }
  // Navigation
  document.addEventListener('click',e=>{
    const nav=e.target.closest('[data-page]');if(nav){e.preventDefault();showPage(nav.dataset.page);}
    const delTask=e.target.closest('[data-delete-task]');if(delTask){state.tasks=state.tasks.filter(x=>String(x.id)!==delTask.dataset.deleteTask);save();renderTasks();}
    const delJournal=e.target.closest('[data-delete-journal]');if(delJournal){state.journals=state.journals.filter(x=>String(x.id)!==delJournal.dataset.deleteJournal);save();renderJournals();}
    const delDream=e.target.closest('[data-delete-dream]');if(delDream){state.dreams=state.dreams.filter(x=>String(x.id)!==delDream.dataset.deleteDream);save();renderDreams();}
    const delTx=e.target.closest('[data-delete-tx]');if(delTx){state.transactions=state.transactions.filter(x=>String(x.id)!==delTx.dataset.deleteTx);save();renderFinance();}
  });
  $('#quickTaskForm').addEventListener('submit',e=>{e.preventDefault();addTask($('#quickTaskInput').value);$('#quickTaskInput').value='';showToast('Тапсырма қосылды ✧');});
  $('#taskForm').addEventListener('submit',e=>{e.preventDefault();addTask($('#taskInput').value,$('#taskPriority').value);$('#taskInput').value='';showToast('Тапсырма қосылды ✧');});
  document.addEventListener('change',e=>{
    if(e.target.matches('.task-check')){const row=e.target.closest('.task-row');const task=state.tasks.find(x=>String(x.id)===row.dataset.id);if(task){task.done=e.target.checked;save();renderTasks();}}
    if(e.target.matches('[data-routine]')){const kind=e.target.dataset.routine,i=Number(e.target.dataset.index);state[kind][i]=e.target.checked;save();}
  });
  $('#waterPlus').addEventListener('click',()=>{state.water=Math.min(30,(state.water||0)+1);save();});
  $('#waterMinus').addEventListener('click',()=>{state.water=Math.max(0,(state.water||0)-1);save();});
  $$('.mood-options button').forEach(b=>b.addEventListener('click',()=>{state.mood=b.dataset.mood;save();}));
  $('#saveJournal').addEventListener('click',()=>{
    const text=$('#journalText').value.trim();if(!text){showToast('Алдымен жазба енгізіңіз.');return;}
    state.journals.unshift({id:Date.now(),text,date:new Date().toLocaleString(state.language==='kk'?'kk-KZ':state.language==='ru'?'ru-RU':'en-US',{dateStyle:'medium',timeStyle:'short'})});
    $('#journalText').value='';save();renderJournals();showToast('Жазба сақталды ♡');
  });
  $('#dreamForm').addEventListener('submit',e=>{e.preventDefault();state.dreams.unshift({id:Date.now(),text:$('#dreamInput').value.trim(),category:$('#dreamCategory').value});$('#dreamInput').value='';save();renderDreams();showToast('Арман картаға қосылды ✧');});
  $('#financeForm').addEventListener('submit',e=>{
    e.preventDefault();const amount=Number($('#financeAmount').value),title=$('#financeTitle').value.trim();if(!title||!Number.isFinite(amount)||amount<=0){showToast('Атауы мен дұрыс соманы енгізіңіз.');return;}
    state.transactions.unshift({id:Date.now(),title,amount,type:$('#financeType').value,date:new Date().toLocaleDateString(state.language==='kk'?'kk-KZ':state.language==='ru'?'ru-RU':'en-US')});
    $('#financeTitle').value='';$('#financeAmount').value='';save();renderFinance();showToast('Операция сақталды.');
  });
  $('#studyNote').addEventListener('input',()=>{state.studyNote=$('#studyNote').value;save();$('#studySaved').textContent='✓';});
  $('#timerStart').addEventListener('click',startTimer);
  $('#timerReset').addEventListener('click',()=>{stopTimer();timerBreak=false;timerSeconds=25*60;timerRender();});
  $('#themeToggle').addEventListener('click',toggleTheme);$('#settingsTheme').addEventListener('click',toggleTheme);
  $('#saveName').addEventListener('click',()=>{state.name=$('#nameInput').value.trim()||'S';save();applyTranslations();showToast('Есім сақталды.');});
  $('#languageSelect').addEventListener('change',e=>{state.language=e.target.value;save();applyTranslations();showToast('Language updated · Тіл өзгертілді');});
  $('#exportDataBtn').addEventListener('click',()=>{
    const blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');
    a.href=url;a.download='girls-life-data.json';document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);showToast('Деректер көшірмесі дайын.');
  });
  $('#clearDataBtn').addEventListener('click',()=>{
    const msg=state.language==='ru'?'Удалить все локальные данные? Это действие нельзя отменить.':state.language==='en'?'Delete all local data? This cannot be undone.':'Барлық жергілікті деректі өшіресіз бе? Бұл әрекетті қайтару мүмкін емес.';
    if(!confirm(msg))return;stopTimer();state=defaultState();try{localStorage.removeItem(KEY);}catch{}document.body.classList.remove('dark');$('#journalText').value='';$('#studySaved').textContent='';applyTranslations();showPage('home');showToast('Деректер тазаланды.');
  });
  // Reset water/mood at local date boundary without erasing the rest of the user's data.
  if(state.dayKey!==dateKey()){state.water=0;state.mood='';state.dayKey=dateKey();save();}
  if(!state.dayKey)state.dayKey=dateKey();
  document.body.classList.toggle('dark',state.theme==='dark');
  applyTranslations();timerRender();
})();
